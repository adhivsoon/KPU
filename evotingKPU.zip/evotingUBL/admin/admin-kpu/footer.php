<div style="height:30px" class="card-panel1 teal lighten-2">
  <div class="center">
    <h6 style="padding-top:8px; color:#FFFFFF">Copyright &copy; 2016 - Kelompok Studi Linux. All right reserved.</h5>
  </div>
</div>
