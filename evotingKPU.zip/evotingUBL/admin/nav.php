<div>
  <a class='dropdown-button btn' href='#' data-activates='dropdown1' style="width:170px">HALAMAN</a>
  <!-- Dropdown Structure -->
  <ul id='dropdown1' class='dropdown-content'>
    <!-- <li><a href="beranda.php">Data Rekapitulasi</a></li> -->
    <li><a href="mhs.php">Data Mahasiswa</a></li>
    <!-- <li><a href="kandidat.php">Data Kandidat</a></li> -->
    <li><a href="eula.php">EULA</a></li>
    <li><a href="logout.php">Keluar</a></li>
  </ul>
</div>
