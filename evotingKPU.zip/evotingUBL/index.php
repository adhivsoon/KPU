<?php
  header("location: mahasiswa/index.php");
 ?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=mahasiswa/index.php">
<title>Artha Laras</title>
<script language="javascript">
    window.location.href = "mahasiswa/index.php"
</script>
</head>
<body>
Go to <a href="admin/index.php">/pages/index.php</a>
</body>
</html>
