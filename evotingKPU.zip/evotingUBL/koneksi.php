<?php
/**
 *
 */
class database
{

  var $host = 'localhost';
  var $user = 'root';
  var $pass = '12345';
  var $db   = 'voting';

  function __construct()
  {
    $koneksi = mysql_connect($this->host, $this->user, $this->pass);
    mysql_select_db($this->db);
    }
  }

$evoting = new database();

?>
