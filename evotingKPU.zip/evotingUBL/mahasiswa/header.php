<div class="card-panel teal lighten-2">
  <div class="left"><img src="../pictures/ubl.png" style="width 130px;height:130px;"></div>
  <div class="right"><img src="../pictures/kpu.png" style="width:120px;height:140px;"></div>
  <div class="center" style="color:#FFFFFF">
    <h4 class="medium"><b class="z-depth-2">PEMILIHAN UMUM</b></h4>
    <!-- <hr width="400px"> -->
    <h5 class="light">Calon Presiden dan Calon Wakil Presiden Mahasiswa
    </br>Universitas Budi Luhur</br>Periode 2016 - 2017</h5>
  </div>
</div>
