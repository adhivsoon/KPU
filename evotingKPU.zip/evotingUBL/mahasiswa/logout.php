<!-- <?php
    session_start();
    session_destroy();
?> -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="refresh" content="4;url=index.php">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Login Pemilihan Umum UBL 2016</title>
  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body class="page-login">
  <center>
  <div class="center">
      <div class="card bordered z-depth-2" style="margin:0% auto; max-width:400px;">
        <div class="card-header">
           <i class="material-icons medium white-text"></i>
			<h4><B>Pemilihan Umum<br></B></h4>
        <h5 class="light">Calon Presiden dan Calon Wakil Presiden Mahasiswa
        </br>Universitas Budi Luhur</br>Periode 2016 - 2017</h5>

        </div>
        <div class="card-content">
          <form name='frm' id='frm' action='' method='post'>
            <div class="input-field col s12">
             <h4 class="center-align" >
	              <b class="z-depth-1">Terimakasih!<br></b>
                  <small>Suara Anda sangat berarti.</small></h4>
            </div>
            <div class="input-field col s12">
             </div>
			<br>
			<img src="../pictures/ubl.png" style="width:65px;height:65px;">&nbsp;&nbsp;
      <img src="../pictures/kpu.png" style="width:60px;height:65px;">&nbsp;&nbsp;
			<img src="../pictures/ksl.png" style="width:65px;height:65px;">
			  <br>
          </form>
</center>
  </body>
</html>
